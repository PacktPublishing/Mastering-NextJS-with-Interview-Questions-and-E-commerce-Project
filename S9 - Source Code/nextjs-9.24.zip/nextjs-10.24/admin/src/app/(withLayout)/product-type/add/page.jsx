import AddProductTypes from "@/screens/product-type/add";


const AddProductTypePage = ({searchParams})=>{

    return(
        <AddProductTypes searchParams={searchParams}/>
    )
};

export default AddProductTypePage;