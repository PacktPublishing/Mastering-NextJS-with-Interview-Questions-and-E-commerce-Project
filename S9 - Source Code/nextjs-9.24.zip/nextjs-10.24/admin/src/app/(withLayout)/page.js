
export default function Home() {
  return (
    <h1>This is the Admin Section.</h1>
  );
}
