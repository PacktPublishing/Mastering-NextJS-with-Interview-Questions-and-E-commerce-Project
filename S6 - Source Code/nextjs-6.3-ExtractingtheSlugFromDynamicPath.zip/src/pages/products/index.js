export default function Products(){

    return(
        <div>
            <h1> This is the /products route. </h1>
        </div>
    )
}