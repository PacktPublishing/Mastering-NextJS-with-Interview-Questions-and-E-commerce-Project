
export default function Header(){

    return(
        <div>
            <a href="/"> Home </a>
            <a href="/products"> Products </a>
            <a href="/products/apple"> Apple </a>
        </div>
    )
}