export default function Apple(){

    return(
        <div>
            <h1> This is the /products/apple route. </h1>
        </div>
    )
}