/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/app/**/*.js',
    './src/component/**/*.js',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

