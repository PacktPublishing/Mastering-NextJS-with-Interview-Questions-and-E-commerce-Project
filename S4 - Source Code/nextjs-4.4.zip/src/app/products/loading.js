export default function ProductsLoading(){

    return(
        <div>
            <h1>Products are Loading... </h1>
            <p>Fetching the requested products.</p>
        </div>
    )
}