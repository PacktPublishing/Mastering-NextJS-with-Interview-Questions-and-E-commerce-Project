export default function Loading(){

    return(
        <div>
            <h1> Loading... </h1>
            <p>Fetching the requested data.</p>
        </div>
    )
}